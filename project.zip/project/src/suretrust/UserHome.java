package suretrust;

public class UserHome {

	public void setTitle(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
