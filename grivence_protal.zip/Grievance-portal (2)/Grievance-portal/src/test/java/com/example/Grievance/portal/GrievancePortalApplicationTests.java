package com.example.Grievance.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrievancePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
