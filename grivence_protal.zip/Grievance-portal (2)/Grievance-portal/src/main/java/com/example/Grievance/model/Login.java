package com.example.Grievance.model;

// public class Login {
    
// }
// package com.example.model;

public class Login {

	private String Email_Id;
	private String password;
	public String getEmail_Id() {
		return Email_Id;
	}
	public void setEmail_Id(String Email_Id) {
		this.Email_Id = Email_Id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginModel [Email_Id=" + Email_Id + ", password=" + password + "]";
	}
	
}