package com.example.Grievance.repository;



import org.springframework.data.repository.CrudRepository;

import com.example.Grievance.model.Complent;







public interface ComplentRepository extends CrudRepository<Complent, Long> {

   // public Grievance save(Grievance grievance);

}
